import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Mhs()
    );
  }
}

class Mhs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Aplikasi Siudin"),
          leading: const Icon(Icons.search),
          centerTitle: true,
          backgroundColor: Colors.lightBlue,
        ),
        backgroundColor: Colors.grey[200],
        body: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            const Text("Data Mahasiswa", textAlign: TextAlign.center),

            const SizedBox(height: 10),
            ListTile(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              leading: const CircleAvatar(backgroundImage: AssetImage('images/adji.jpg'),),
              title: const Text('Dian Restu Adji', style: TextStyle(fontWeight: FontWeight.bold),),
              subtitle: const Text('F12.2022.00056 \nIPK 4'),
              trailing: const Icon(Icons.arrow_forward_ios),
              tileColor: Colors.white,
              onTap: () {
                Navigator.push(context,
                MaterialPageRoute(builder: (context) => BioAdji()),
                );
              },
            ),
            
            const SizedBox(height: 10),
            ListTile(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              leading: const CircleAvatar(backgroundImage: AssetImage('images/mela.jpg'),),
              title: const Text('Pita mellati', style: TextStyle(fontWeight: FontWeight.bold),),
              subtitle: const Text('F12.2022.00061 \nIPK 4'),
              trailing: const Icon(Icons.arrow_forward_ios),
              tileColor: Colors.white,
              onTap: () {
                Navigator.push(context,
                MaterialPageRoute(builder: (context) => BioMela()),
                );
              },
            ),
            
            const SizedBox(height: 10),
            ListTile(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              leading: const CircleAvatar(backgroundImage: AssetImage('images/kenza.jpg'),),
              title: const Text('Kenza Amelia Putri Anwarri', style: TextStyle(fontWeight: FontWeight.bold),),
              subtitle: const Text('F12.2022.00072 \nIPK 4'),
              trailing: const Icon(Icons.arrow_forward_ios),
              tileColor: Colors.white,
              onTap: () {
                Navigator.push(context,
                MaterialPageRoute(builder: (context) => BioKenza()),
                );
              },
            ),

            const SizedBox(height: 20),
              Center(
                child: SizedBox( 
                  child: ElevatedButton(
                    onPressed:() {},    
                    child: const Text("Print", style: TextStyle(fontSize: 18, color: Colors.black))
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class BioAdji extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Aplikasi Siudin"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      backgroundColor: Colors.grey[200],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: Colors.white,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('images/adji.jpg'), // Sesuaikan path gambar Anda
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Biodata Mahasiswa',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const Divider(thickness: 1, color: Colors.grey),
                const SizedBox(height: 8),
                buildRow('Nama', 'Dian Restu Adji'),
                const SizedBox(height: 8),
                buildRow('NIM', 'F12.2022.00056'),
                const SizedBox(height: 8),
                buildRow('Jurusan', 'Sistem Informasi'),
                const SizedBox(height: 8),
                buildRow('Fakultas', 'Ilmu Komputer'),
                const SizedBox(height: 8),
                buildRow('Angkatan', '2022'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
          ),
        ),
      ],
    );
  }
}

class BioMela extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Aplikasi Siudin"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      backgroundColor: Colors.grey[200],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: Colors.white,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('images/mela.jpg'), // Sesuaikan path gambar Anda
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Biodata Mahasiswa',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const Divider(thickness: 1, color: Colors.grey),
                const SizedBox(height: 8),
                buildRow('Nama', 'Pita Mellati'),
                const SizedBox(height: 8),
                buildRow('NIM', 'F12.2022.00061'),
                const SizedBox(height: 8),
                buildRow('Jurusan', 'Sistem Informasi'),
                const SizedBox(height: 8),
                buildRow('Fakultas', 'Ilmu Komputer'),
                const SizedBox(height: 8),
                buildRow('Angkatan', '2022'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
          ),
        ),
      ],
    );
  }
}

class BioKenza extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Aplikasi Siudin"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      backgroundColor: Colors.grey[200],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: Colors.white,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('images/kenza.jpg'), // Sesuaikan path gambar Anda
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Biodata Mahasiswa',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const Divider(thickness: 1, color: Colors.grey),
                const SizedBox(height: 8),
                buildRow('Nama', 'Kenza Amelia Putri Anwarrri'),
                const SizedBox(height: 8),
                buildRow('NIM', 'F12.2022.00072'),
                const SizedBox(height: 8),
                buildRow('Jurusan', 'Sistem Informasi'),
                const SizedBox(height: 8),
                buildRow('Fakultas', 'Ilmu Komputer'),
                const SizedBox(height: 8),
                buildRow('Angkatan', '2022'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
          ),
        ),
      ],
    );
  }
}